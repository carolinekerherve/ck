#!/usr/bin/perl

use MT;
use MT::Plugin;

package MT::Plugin::OpenIDComment;


MT::Template::Context->add_tag(CommentAuthorIdentity => \&identity_link);
MT::Template::Context->add_tag(OpenIDSignOnURL => \&signon_url);
MT::Template::Context->add_tag(OpenIDSignOnThunk => \&signon_thunk);
MT::Template::Context->add_tag(LiveJournalSignOnThunk => \&signon_thunk);


our $plugin_obj = MT::Plugin->new({
    name => 'OpenID Comments',
    version => 1.2,
    description => 'Empowers commenters to sign in with OpenID to comment',

    settings => MT::PluginSettings->new([
        ['enable',     { Default => 1, Scope => 'blog' }],
        ['special_lj', { Default => 1, Scope => 'blog' }],
    ]),
    blog_config_template => 'blog_config.tmpl',
});
MT->add_plugin($plugin_obj);


sub identity_link {
    my ($ctx, $args) = @_;
    my $cmt = $ctx->stash('comment')
        or return $ctx->_no_comment_error('MT' . $ctx->stash('tag'));
    my $config = $plugin_obj->get_config_hash('blog:'. $ctx->stash('blog_id'));
    ## Don't check for enablement here, so we can handle if OpenID comments are made,
    ## then OpenID is disabled.
    if($cmt->commenter_id) {
        my $auth = MT::Author->load($cmt->commenter_id) or return "?";
        my $name = $auth->name;
        if($name =~ m(^openid\n(.*)$)) {
            my $cfg = MT::ConfigMgr->instance;
            my $assets_path = ($cfg->StaticWebPath || $cfg->CGIPath) . 'openid-comment';
            my $identity = $1;
            if($config->{special_lj} && $identity =~ m(^http://www.livejournal.com/users/([^/]+))) {
                return qq(<a class="commenter-profile" href="${identity}info"><img alt="[LiveJournal user info]" src="$assets_path/livejournal.gif" width="17" height="17" /></a>);
            }
            return qq(<a class="commenter-profile" href="$identity"><img alt="[OpenID Commenter Profile]" src="$assets_path/openid.gif" width="16" height="16" /></a>);
        }
    }
    return $ctx->_hdlr_comment_author_identity($args);
}

sub signon_url {
    my ($ctx, $args) = @_;
    my $cgipath = $ctx->_hdlr_cgi_path;
    "${cgipath}plugins/openid-comment/signon.cgi";
}

sub signon_thunk {
    my ($ctx, $args) = @_;
    my $signon_url = signon_url($ctx, $args);
    my $assets_path = MT->instance->static_path . 'openid-comment';
    my $entry_id = $ctx->stash('entry')->id;

    my $livejournal = $ctx->stash('tag') eq 'LiveJournalSignOnThunk' ? 1 : 0;
    my $field_label = $livejournal ? 'Your LiveJournal username' : 'Your blog URL';
    my $field_name  = $livejournal ? 'user' : 'openid_url';
    my $image_name  = $livejournal ? 'livejournal' : 'openid';
    
    <<EOF;
<div id="openid">
<form method="post" action="$signon_url">
<input type="hidden" name="entry_id" value="$entry_id" />
<input type="hidden" name="__mode" value="signon" />
<p>
<label>$field_label: <input name="$field_name" size="30" value="" style="background: url($assets_path/$image_name.gif) no-repeat; padding-left: 18px;" /></label>
<input type="submit" value="Sign in" />
</p>
</form>
</div>
EOF
}


1;

