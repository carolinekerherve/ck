<?php
function smarty_modifier_encode_url($text) {
    return urlencode($text);
}
?>
