<?php
function smarty_function_MTImageURL($args, &$ctx) {
    return $ctx->stash('ImageURL');
}
?>
