<?php
function smarty_function_MTCalendarDate($args, &$ctx) {
    return $ctx->_hdlr_date($args, $ctx);
}
?>
