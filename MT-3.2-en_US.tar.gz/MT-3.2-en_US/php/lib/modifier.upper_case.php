<?php
function smarty_modifier_upper_case($text) {
    return strtoupper($text);
}
?>
