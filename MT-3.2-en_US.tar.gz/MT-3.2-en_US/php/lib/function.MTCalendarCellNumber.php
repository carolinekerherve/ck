<?php
function smarty_function_MTCalendarCellNumber($args, &$ctx) {
    return $ctx->stash('CalendarCellNumber');
}
?>
