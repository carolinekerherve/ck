<?php
function smarty_function_MTImageWidth($args, &$ctx) {
    // todo: needs work
    return $ctx->stash('ImageWidth');
}
?>
