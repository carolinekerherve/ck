<?php
function smarty_function_MTGoogleSearchResult($args, &$ctx) {
    // todo: needs work
    return $ctx->stash('GoogleSearchResult');
}
?>
