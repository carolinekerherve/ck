<?php
function smarty_function_MTConfigFile($args, &$ctx) {
    // status: complete
    // parameters: none
    return $ctx->mt->cfg_file;
}
?>
