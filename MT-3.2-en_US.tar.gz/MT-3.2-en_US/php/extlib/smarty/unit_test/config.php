<?php

define('SMARTY_DIR', '../libs/');

?>
