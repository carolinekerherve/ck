<?php
define("WEBMASTER_EMAIL", 'your-email@address-here.com');
?>